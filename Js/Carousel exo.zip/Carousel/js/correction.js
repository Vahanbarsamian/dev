
//#play #next #previous #random


//src et légende
var slides = [
    { image: 'images/1.jpg', legend: 'Street Art'          },
    { image: 'images/2.jpg', legend: 'Fast Lane'           },
    { image: 'images/3.jpg', legend: 'Colorful Building'   },
    { image: 'images/4.jpg', legend: 'Skyscrapers'         },
    { image: 'images/5.jpg', legend: 'City by night'       },
    { image: 'images/6.jpg', legend: 'Tour Eiffel la nuit' }
];

//next : passe à l'image suivante
//previous : revient à l'image précédente
//random : affiche image aléatoire
//play

function nextImage(){
    if(index == slides.length -1){
    	index = 0;
    } else {
		index++;
    }
    afficherPhoto();
}

function prevImage(){
	if (index == 0){
    	index = slides.length - 1;
    } else {
    	index--;
    }
    afficherPhoto();
}

function randomImage(){
	var random; 
    do {
    	random = Math.floor(Math.random()*slides.length); 
    } while(index == random);
    index = random;
    afficherPhoto();
}

function afficherPhoto(){
	//document.querySelector("#image").setAttribute("src", slides[index].src);
    document.querySelector("#image").src = slides[index].src;
    document.querySelector("#legend").textContent = slides[index].legend;
}




document.addEventListener('DOMContentLoaded', function (){

	index = 0;
    timer = null;
    
    addEvent('#next', 'click', nextImage);
    addEvent('#play', 'click', playDiapo);
    addEvent('#previous', 'click', prevImage);
    addEvent('#random', 'click', randomImage);
    
    afficherPhoto();

});


function addEvent(id, evenement, fonction){//sélecteur, l'événement déclencheur, fonction à appeler
	document.querySelector(id).addEventListener(evenement, fonction);
}